(function ($) {
    // USE STRICT
    "use strict";

    $(".form-radio .radio-item").click(function(){
        //Spot switcher:
        $(this).parent().find(".radio-item").removeClass("active");
        $(this).addClass("active");
    });
  
    $('#district_type').parent().append('<ul class="list-item" id="newdistrict_type" name="district_type"></ul>');
    $('#district_type option').each(function(){
        $('#newdistrict_type').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#district_type').remove();
    $('#newdistrict_type').attr('id', 'district_type');
    $('#district_type li').first().addClass('init');
    $("#district_type").on("click", ".init", function() {
        $(this).closest("#district_type").children('li:not(.init)').toggle('fast');
    });


    $('#medium').parent().append('<ul class="list-item" id="newmedium" name="medium"></ul>');
    $('#medium option').each(function(){
        $('#newmedium').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#medium').remove();
    $('#newmedium').attr('id', 'medium');
    $('#medium li').first().addClass('init');
    $("#medium").on("click", ".init", function() {
        $(this).closest("#medium").children('li:not(.init)').toggle('fast');
    });


    $('#background').parent().append('<ul class="list-item" id="newbackground" name="background"></ul>');
    $('#background option').each(function(){
        $('#newbackground').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#background').remove();
    $('#newbackground').attr('id', 'background');
    $('#background li').first().addClass('init');
    $("#background").on("click", ".init", function() {
        $(this).closest("#background").children('li:not(.init)').toggle('fast');
    });

    $('#T_gender').parent().append('<ul class="list-item" id="newT_gender" name="T_gender"></ul>');
    $('#T_gender option').each(function(){
        $('#newT_gender').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#T_gender').remove();
    $('#newT_gender').attr('id', 'T_gender');
    $('#T_gender li').first().addClass('init');
    $("#T_gender").on("click", ".init", function() {
        $(this).closest("#T_gender").children('li:not(.init)').toggle('fast');
    });
    

    $('#S_gender').parent().append('<ul class="list-item" id="newS_gender" name="S_gender"></ul>');
    $('#S_gender option').each(function(){
        $('#newS_gender').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#S_gender').remove();
    $('#newS_gender').attr('id', 'S_gender');
    $('#S_gender li').first().addClass('init');
    $("#S_gender").on("click", ".init", function() {
        $(this).closest("#S_gender").children('li:not(.init)').toggle('fast');
    });

    

    $('#confirm_type').parent().append('<ul class="list-item" id="newconfirm_type" name="confirm_type"></ul>');
    $('#confirm_type option').each(function(){
        $('#newconfirm_type').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#confirm_type').remove();
    $('#newconfirm_type').attr('id', 'confirm_type');
    $('#confirm_type li').first().addClass('init');
    $("#confirm_type").on("click", ".init", function() {
        $(this).closest("#confirm_type").children('li:not(.init)').toggle('slow');
    });
    
    $('#hour_appointment').parent().append('<ul class="list-item" id="newhour_appointment" name="hour_appointment"></ul>');
    $('#hour_appointment option').each(function(){
        $('#newhour_appointment').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
    });
    $('#hour_appointment').remove();
    $('#newhour_appointment').attr('id', 'hour_appointment');
    $('#hour_appointment li').first().addClass('init');
    $("#hour_appointment").on("click", ".init", function() {
        $(this).closest("#hour_appointment").children('li:not(.init)').toggle('slow');
    });

    var allOptions = $("#course_type").children('li:not(.init)');
    $("#course_type").on("click", "li:not(.init)", function() {
        allOptions.removeClass('selected');
        $(this).addClass('selected');
        $("#course_type").children('.init').html($(this).html());
        allOptions.toggle('slow');
    });

    var FoodOptions = $("#confirm_type").children('li:not(.init)');
    $("#confirm_type").on("click", "li:not(.init)", function() {
        FoodOptions.removeClass('selected');
        $(this).addClass('selected');
        $("#confirm_type").children('.init').html($(this).html());
        FoodOptions.toggle('slow');
    });

    var AppointmentOptions = $("#hour_appointment").children('li:not(.init)');
    $("#hour_appointment").on("click", "li:not(.init)", function() {
        AppointmentOptions.removeClass('selected');
        $(this).addClass('selected');
        $("#hour_appointment").children('.init').html($(this).html());
        AppointmentOptions.toggle('slow');
    });
})(jQuery);