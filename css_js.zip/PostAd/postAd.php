<?php
session_start();

require_once('connection.php'); 
require('postAd.html');

$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
	
	if (isset($_SESSION['email'])) {
		$email = $_SESSION['email'];
	}
	if(!isset($_SESSION['username'])) {
    		echo "<script>alert('You must login first!'); window.location = './login.php'; </script>";
    }

	if(isset($_POST) && !empty($_POST)) {

		$name = mysqli_escape_string($connection, $_POST['name']);
		$phone_number = mysqli_escape_string($connection, $_POST['phone_number']);
		$district = mysqli_escape_string($connection,$_POST['district_type']);
		$S_gender = mysqli_escape_string($connection,$_POST['S_gender']);
		$T_gender = mysqli_escape_string($connection, $_POST['T_gender']);

		$medium = mysqli_escape_string($connection,$_POST['medium']);
		$background = mysqli_escape_string($connection, $_POST['background']);
		$class = mysqli_escape_string($connection, $_POST['class']);
		$daysPerWeek = mysqli_escape_string($connection, $_POST['daysPerWeek']);
		$salary = mysqli_escape_string($connection, $_POST['salary']);
    	
		$imgFile = $_FILES['image']['name']; 
			
			if(empty($imgFile)){
		  		$errMSG = "Please Select Image File.";
		  	}

		  	else {
				require_once('uploadImage.php');

		  		if(!isset($errMSG)) {
		  			
		  			
					$query1 = "INSERT INTO stuAd()   
						       VALUES ('$name','$phone_number','$email','$district','$S_gender','$T_gender','$medium','$background','$class', '$daysPerWeek','$salary')" ;
					$result1 = mysqli_query($connection, $query1);
		
				  	if($result1) {
						echo "<script>alert('Your post submitted successfully!'); window.location = './viewPosts.php'; </script>";	
				 	}
				    else {
					    $fmsg = "Submission not completed!";
		    	    }
				}    
		} 
	} 
	require('postAd.html');
?>