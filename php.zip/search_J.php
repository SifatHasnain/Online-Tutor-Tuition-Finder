<?php
error_reporting(0);
    session_start();
    require('connection.php');
     
    /*$area = $_POST['area'];
    $grade = $_POST['grade'];
    $subjects = $_POST['subjects'];
    $salary = $_POST['salary'];*/
    if(isset($_POST) && !empty($_POST)) {
     
        $area = mysqli_escape_string($connection, $_POST['area']);
        $grade = mysqli_escape_string($connection, $_POST['grade']);
				
		$subject = mysqli_escape_string($connection, $_POST['subject']);
					
 		$salary = mysqli_escape_string($connection, $_POST['salary']);
				
        $gender = mysqli_escape_string($connection, $_POST['S_gender']);
                            
        $qry = "SELECT * FROM studentad where Area LIKE '$area' OR      
               Grade LIKE '$grade' OR
               S_gender LIKE '$gender' OR Subject LIKE '$subject' OR
               Salary LIKE '$salary';"; 
        $result = mysqli_query($connection, $qry);
        $id = -1;                  
        if((mysqli_num_rows($result)>0)) {
            $id = 0;

            while($row = mysqli_fetch_array($result)) {
                
              $row2[$id]['name'] = $row['name'];
              $row2[$id]['City'] = $row['City'];
              $row2[$id]['Subject'] = $row['Subject'];
              $row2[$id]['Salary'] = $row['Salary'];
              $row2[$id]['Grade'] = $row['Grade'];
              $row2[$id]['details'] = $row['details'];
              $row2[$id]['img'] = $row['img'];
              $row2[$id]['T_gender'] = $row['T_gender'];
              $row2[$id]['S_gender'] = $row['S_gender'];
              $row2[$id]['S_email'] = $row['S_email'];
              $row2[$id]['S_phn'] = $row['S_phn'];
              $id++;
            } 
        }
        else {
            echo "<script> alert('Search not found!')</script>";
             $id =-1;
        }
    
    
}
    require_once('searchJob.html');
?>
</body>

</html>
