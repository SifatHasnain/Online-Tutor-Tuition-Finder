<?php
session_start();

require_once('connection.php');

$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];

    if(isset($_SESSION['email'])) {
        #header('location: ' .$_SESSION['redirect_url'] );
        echo "<script>alert('Already logged in!');  </script>";
        header('location: ' .$_SESSION['redirect_url'] );

    }

    else if(isset($_POST) && !empty($_POST)){
        
        $email = mysqli_escape_string($connection, $_POST['email']);
        $password = md5($_POST['password']); //calculates hash
       

        $slquery = "SELECT * FROM account WHERE email = '$email' AND password = '$password'";
        $selectresult = mysqli_query($connection, $slquery);
        $row = mysqli_fetch_array($selectresult);

        if($selectresult) {
            $_SESSION['email'] = $row['email'];
            $_SESSION['username'] = $row['username'];
            echo "<script>alert('Login successful!'); window.location = './homepage.php'; </script>";
        } else {
            echo "<script>alert('Invalid email/password!');window.history.back();</script>";
        }
    }
    require_once('login.html');
?>