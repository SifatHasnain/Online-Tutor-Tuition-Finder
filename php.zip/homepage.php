<?php
	
  session_start();
  require('homepageHeader.php');//all css, google fonts and bootstrap compiled links are in the head of html//html body starts here
  $_SESSION['entry'] = 0;
  require('homepage.html'); 
  //require('searchBox.html');

  $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
  
?>