<?php

require_once('connection.php'); 
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
	$email = $_SESSION['email'] ;
	
	if(isset($_POST) && !empty($_POST)) {
		$name = mysqli_escape_string($connection, $_POST['name']);
		$phn = mysqli_escape_string($connection, $_POST['phn']);
		$profession = mysqli_escape_string($connection,$_POST['profession']);
		$address = mysqli_escape_string($connection, $_POST['address']);
		$area = mysqli_escape_string($connection, $_POST['area']);
		$city = mysqli_escape_string($connection, $_POST['city']);
		$T_gender = mysqli_escape_string($connection,$_POST['T_gender']);
		$S_gender = mysqli_escape_string($connection, $_POST['S_gender']);
		#$medium = mysqli_escape_string($connection,$_POST['medium']);
		$details = mysqli_escape_string($connection, $_POST['details']);
		#$daysPerWeek = mysqli_escape_string($connection, $_POST['daysPerWeek']);
		$salary = mysqli_escape_string($connection, $_POST['salary']);
    	
		$imgFile = $_FILES['image']['name']; 
			
			if(empty($imgFile)){
		  		$errMSG = "Please Select Image File.";
		  	}
		  	else {
				require_once('uploadImage.php');
		  		if(!isset($errMSG)) {
		  			
		  			
					$query1 = "INSERT INTO tutorad(name, T_email, T_phn, Address, Area, City, S_gender, T_gender, profession, Salary, details, img)   
						       VALUES ('$name', '$email', '$phn', '$address', LOWER('$area'),LOWER('$city'), '$S_gender','$T_gender', '$profession', '$salary', '$details','$imgFile')" ;
					$result1 = mysqli_query($connection, $query1);
		
				  	if($result1) {
						echo "<script>alert('Your post submitted successfully!'); window.location = './viewPosts.php'; </script>";	
				 	}
				    else {
					    $fmsg = "Submission not completed!";
		    	    }
				}    
		} 
	} 
	
?>