<script>
	<?php session_start(); session_destroy(); ?>
	alert('Thank you!Come again.');
	window.location = './homepage.php';
</script>