	
<script> 
	var logout = confirm("Are you sure to logout?");

    if(logout) {  
		window.location = './logout1.php'; //logout1.php to show come back msg and session_destroy()//same file was not doing it properly
    }
	else {
		<?php session_start(); ?>
		window.history.back();
	}

</script>

