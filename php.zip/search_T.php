<?php
error_reporting(0);
    session_start();
    require('connection.php');
    if(isset($_POST) && !empty($_POST)) {
   

        
        $area = mysqli_escape_string($connection,$_POST['area']);
                         
        $profession = mysqli_escape_string($connection,$_POST['profession']);
						
 		$salary = mysqli_escape_string($connection, $_POST['salary']);
							 
        $gender = mysqli_escape_string($connection, $_POST['T_gender']);
                             
        $qry = "SELECT * FROM tutorad where Area LIKE '$area' OR profession LIKE '$profession' OR T_gender LIKE '$gender' OR Salary LIKE '$salary';";
        $result = mysqli_query($connection, $qry);
        $id = -1;
        if(mysqli_num_rows($result)!=0) {
            $id = 0;

            while($row2 = mysqli_fetch_array($result)) {
                
                  $row[$id]['name'] = $row2['name'];
                  $row[$id]['City'] = $row2['City'];
                  $row[$id]['profession'] = $row2['profession'];
                  $row[$id]['Salary'] = $row2['Salary'];
                  $row[$id]['details'] = $row2['details'];
                  $row[$id]['img'] = $row2['img'];
                  $row[$id]['T_gender'] = $row2['T_gender'];
                  $row[$id]['S_gender'] = $row2['S_gender'];
                  $row[$id]['T_email'] = $row2['T_email'];
                  $row[$id]['T_phn'] = $row2['T_phn'];
                  $id++;
            } 
        }
        else {
            
            echo "<script> alert('Search not found!')</script>";
            $id = -1;
        }
    }

     require_once('searchTutor.html');
?>

<!--$id = $row['ID'];
            if(!isset($_SESSION['email'])) {
            
                echo "<div class='row border'>";
                    
                    echo "<div>";
                        echo "<div class = 'textdecor1'>";
                  
                            echo "<div class = 'col-md-3 formline'>";
                                echo " Name: ".ucwords($row['name'])."<br>";
                                echo " Gender: ".ucwords($row['T_gender'])."<br>";
                                echo " Salary Offer: Tk.".$row['Salary']."TK<br>";
                                echo "  Current Occupation: ".$row['profession']."<br>";
                                #echo "  Subjects: ".$row['Subject']."<br>";
                                echo " Location : ".ucwords($row['City'])."<br>";
                                echo " Login to view full details"."<br>";
                            echo "</div>";                
                        
                    echo "</div>";
                echo "</div>";
            } else {
                    echo "<script>alert('Login successful!'); window.location = './viewPosts.php'; </script>";
            }-->