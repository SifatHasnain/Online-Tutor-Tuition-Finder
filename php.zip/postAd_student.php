<?php


require_once('connection.php'); 

$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
	
	$email = $_SESSION['email'] ;
	if(isset($_POST) && !empty($_POST)) {

		$name = mysqli_escape_string($connection, $_POST['name']);
		$phn = mysqli_escape_string($connection, $_POST['phn']);

		if(!empty($_POST['subject'])) {
			
			// As output of $_POST['Color'] is an array we have to use Foreach Loop to display individual value
			foreach ($_POST['subject'] as $select) {
				$string = $string."' ".$_POST['subject'];
			}
		}
		
		$T_gender = mysqli_escape_string($connection,$_POST['T_gender']);
		$S_gender = mysqli_escape_string($connection, $_POST['S_gender']);
		$subject = mysqli_escape_string($connection,$string);
		$grade = mysqli_escape_string($connection, $_POST['grade']);
		$salary = mysqli_escape_string($connection, $_POST['salary']);
		$address = mysqli_escape_string($connection, $_POST['address']);
		$area = mysqli_escape_string($connection, $_POST['area']);
		$city = mysqli_escape_string($connection, $_POST['city']);
		$details = mysqli_escape_string($connection, $_POST['details']);

    	
			
			$imgFile = $_FILES['image']['name']; 
			
			if(empty($imgFile)){
		  		$errMSG = "Please Select Image File.";
		  	}

		  	else {
				require_once('uploadImage.php');

		  		if(!isset($errMSG)) {
		  			
		  			
				#	$query1 = "INSERT INTO student(name, S_email, S_phn)   
						    #       VALUES ('name', '$email', '$phn') 
						#           ON DUPLICATE KEY UPDATE name='$name',S_phn =  '$phn'";
					#$result1 = mysqli_query($connection, $query1);
					

				    $query2 = "INSERT INTO studentad(name, S_email, S_phn, Address, Area, City, S_gender, T_gender, Subject, Grade, Salary, details, img) 
				               VALUES ('$name', '$email', '$phn', '$address', LOWER('$area'),LOWER('$city'), '$S_gender','$T_gender', '$subject', '$grade', '$salary', '$details','$imgFile')";
					$result2 = mysqli_query($connection, $query2);
				  
				  	if($result2) {
						echo "<script>alert('Your post submitted successfully!'); window.location = './viewPosts.php'; </script>";	
				 	}
				    else {
					    $fmsg = "Submission not completed!";
		    	    }
				}    
		} 
	} 

	echo "<div class='col-md-6' style='float: right; top: 60%; width: 30%;'>";
	if(isset($fmsg)) {
		echo "<script>alert($fmsg);window.history.back();</script>";	
	} 
	else if(isset($errMSG)) {
		echo "<script>alert($errMSG);window.history.back();</script>";	
	}
	echo "</div>";
	#require('postAd.html');
?>