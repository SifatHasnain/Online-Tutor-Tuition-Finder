<?php

	$connection = mysqli_connect('localhost', 'sifat', '5YyWGvr6');//host,username,pass//connecting to xampp

	if (!$connection){
	    
	    die("Database Connection Failed" . mysqli_error($connection));

	}

	$select_db = mysqli_select_db($connection, 'sifat_TuitionFinder');

	if (!$select_db){
	   
	    die("Database Selection Failed" . mysqli_error($connection));
	    
	}

?>