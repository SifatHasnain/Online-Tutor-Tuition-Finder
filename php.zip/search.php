<?php
    session_start();
    require_once('connection.php');
    require_once('searchJob.html'); 
    /*$area = $_POST['area'];
    $grade = $_POST['grade'];
    $subjects = $_POST['subjects'];
    $salary = $_POST['salary'];*/
    $qry = "SELECT * FROM studentads";
      $searchArray = array();

        if (isset($_POST['district'])) {
        $searchArray[] = "area LIKE '%".mysql_real_escape_string($area) . "%'";
                           } 
        if (isset($_POST['class'])) {
       $searchArray[] = "class LIKE '%".mysql_real_escape_string($class) . "%'";
						} 
		/*if (isset($_POST['subject'])) {
		 $searchArray[] = "subjects LIKE '%".mysql_real_escape_string($subject) . "%'";
					}*/
		if (isset($_POST['salary'])) {
 		$searchArray[] = "salary LIKE '%".mysql_real_escape_string($salary) . "%'";
							  }
    $result = mysqli_query($connection, $qry);

if(isset($_POST["submit"])) {

    if((mysqli_num_rows($result)>0)) {

        while($row = mysqli_fetch_array($result)) {
            
            $id = $row['ID'];
            
            echo "<div class='row border'>";
                
                echo "<div>";
                    echo "<div class = 'textdecor1'>";
              
                        echo "<div class = 'col-md-3 formline'>";
                            echo " Name: ".ucwords($row['name'])."<br>";
                            echo " Salary Offer: Tk.".$row['salary']."TK<br>";
                            echo "  Currently Studying: ".$row['class']."<br>";
                            echo "  Subjects: ".$row['subject']."<br>";
                            echo " Location : ".ucwords($row['district'])."<br>";
                            echo " Phone NO:: ".$row['phoneNo']."<br>";
                        echo "</div>";                
                    
                echo "</div>";
            echo "</div>";
        } 
    }
    else {
        echo "<div style='padding-left: 20px; font-size:25px;'>";
        echo "Search not found!</div>";
    }}
?>
</body>

</html>
