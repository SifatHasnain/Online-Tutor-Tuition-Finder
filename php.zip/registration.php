<?php

require_once('connection.php');
session_start();

	if(isset($_POST) && !empty($_POST)){
		
		$username = mysqli_escape_string($connection, $_POST['username']);
	    $email = mysqli_escape_string($connection, $_POST['email']);
		$password = md5($_POST['password']); //calculates hash
		$cpassword = md5($_POST['confirm_password']);

    	$slquery = "SELECT COUNT(*) FROM account WHERE email = '$email'";
    	$selectresult = mysqli_query($connection, $slquery);
    	$row = mysqli_fetch_array($selectresult);

    	if($row[0]==1) {

        	/*echo "";*/
        	echo "<script>alert('Email already exists!');window.history.back();</script>";

    	}
    	elseif($password != $cpassword){

        	echo "<script>alert('Passwords do not match!');window.history.back();</script>";

    	}
    	else {

			$query = "INSERT INTO account(username, email, password) VALUES ('$username', '$email', '$password')";
			$result = mysqli_query($connection, $query);
			
			if($result) {
				echo "<script>alert('Registration successful!'); window.location = './homepage.php'; </script>";
			} else {
				echo "<script>alert('Registration unsuccessful!');window.history.back();</script>";"";
			}
	 	}
	}
require_once('registration.html');
?>