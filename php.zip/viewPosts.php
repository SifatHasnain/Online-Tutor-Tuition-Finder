<?php
session_start();
require('connection.php');

$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];

		if (isset($_SESSION['email'])) {
			$email = $_SESSION['email'];
		}
    else {
      echo "<script>alert('You must login first!'); window.location = './login.php'; </script>";
    }

		$query1 = "SELECT * 
              FROM studentad
              WHERE S_email = '$email'";

    $query2 = "SELECT * 
              FROM tutorad
              WHERE T_email = '$email'";
    $result1 = mysqli_query($connection, $query1);
    $result2 = mysqli_query($connection, $query2);
    
    if(mysqli_num_rows($result1)==0 or mysqli_num_rows($result2)==0) {

       echo "<script>alert('You have no posts yet!'); window.location = './homepage.php';</script>";
            
    }

        else {
          $id1 = 0;
          $id2 = 0;
          while($row1=mysqli_fetch_array($result1) ) {
             // $row1 = mysqli_fetch_array($result1) ;
              
              $row3[$id1]['name'] = $row1['name'];
              $row3[$id1]['City'] = $row1['City'];
              $row3[$id1]['Grade'] = $row1['Grade'];
              $row3[$id1]['Subject'] = $row1['Subject'];
              $row3[$id1]['Salary'] = $row1['Salary'];
              $row3[$id1]['details'] = $row1['details'];
              $row3[$id1]['img'] = $row1['img'];
              $row3[$id1]['T_gender'] = $row1['T_gender'];
              $row3[$id1]['S_gender'] = $row1['S_gender'];
              $row3[$id1]['S_email'] = $row1['S_email'];
              $row3[$id1]['S_phn'] = $row1['S_phn'];
              $id1++;
              
          }  
           while($row2=mysqli_fetch_array($result2)) {
              
              //$row2 = mysqli_fetch_array($result2);
             
              $row4[$id2]['name'] = $row2['name'];
              $row4[$id2]['City'] = $row2['City'];
              $row4[$id2]['profession'] = $row2['profession'];
              $row4[$id2]['Salary'] = $row2['Salary'];
              $row4[$id2]['details'] = $row2['details'];
              $row4[$id2]['img'] = $row2['img'];
              $row4[$id2]['T_gender'] = $row2['T_gender'];
              $row4[$id2]['S_gender'] = $row2['S_gender'];
              $row4[$id2]['T_email'] = $row2['T_email'];
              $row4[$id2]['T_phn'] = $row2['T_phn'];
              $id2++;
          }  
        }
          require('viewPosts.html');
        
?>
</body>

</html>