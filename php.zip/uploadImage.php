<?php
	$imgFile = $_FILES['image']['name'];
	$tmp_dir = $_FILES['image']['tmp_name'];
	$imgSize = $_FILES['image']['size'];


	$upload_dir = "uploads/"; // upload directory 
					 
	$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); //get image extension PATHINFO_EXTENSION- return only extension
					  
	// valid image extensions
	$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
					  
	// rename uploading image
	$Image = rand(1000,1000000).".".$imgExt;
					    
	// allow valid image file formats
    if(in_array($imgExt, $valid_extensions)){   
		// Check file size '5MB'
		if($imgSize < 5000000)    {
			move_uploaded_file($tmp_dir, $upload_dir. $Image); //file,new location
		}
		else{
			$errMSG = "Sorry, your file is too large.";
		}
	}
	else{
		$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";  
	}
?> 		