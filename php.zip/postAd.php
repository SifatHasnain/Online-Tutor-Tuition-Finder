<?php
session_start();

require_once('connection.php'); 
 
 
$_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
	
	if (isset($_SESSION['email'])) {
		$email = $_SESSION['email'];
	}
	else {
    		echo "<script>alert('You must login first!'); window.location = './login.php'; </script>";
    }
    
    require('postAd.html'); 
?>